<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Service extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'excerpt',
        'content',
        'base_price',
        'position',
        'is_active',
        'image_path',
        'lead',
'content_heading',
'content_md',
'bottom_note',

    ];

    protected $casts = [
        'is_active'  => 'boolean',
        'base_price' => 'float',
        'position'   => 'integer',
        'lead' => 'string',
'content_heading' => 'string',
'content_md' => 'string',
'bottom_note' => 'string',

    ];

    protected static function booted(): void
    {
        // Génération du slug s’il est vide (unicité garantie)
        static::saving(function (Service $service) {
            if (empty($service->slug) && !empty($service->name)) {
                $base = Str::slug($service->name, '-');
                $slug = $base ?: 'service-'.($service->id ?? uniqid());
                $i = 2;
                while (
                    self::where('slug', $slug)
                        ->when($service->id, fn($q) => $q->where('id', '!=', $service->id))
                        ->exists()
                ) {
                    $slug = $base.'-'.$i;
                    $i++;
                }
                $service->slug = $slug;
            }
        });

        // Suppression de l’image sur delete (évite les fichiers orphelins)
        static::deleting(function (Service $service) {
            if ($service->image_path && Storage::disk('public')->exists($service->image_path)) {
                Storage::disk('public')->delete($service->image_path);
            }
        });
    }
}
