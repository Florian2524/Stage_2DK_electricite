<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Service;

class ServicePublicController extends Controller
{
    public function index()
    {
        $services = Service::query()
            ->where('is_active', true)
            ->orderBy('position')
            ->orderBy('name')
            ->get(['name','slug','excerpt','image_path']);

        return response()->json($services);
    }

    public function show(string $slug)
    {
        $service = Service::query()
            ->where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail(['name','slug','excerpt','content','image_path','base_price']);

        return response()->json($service);
    }
}
