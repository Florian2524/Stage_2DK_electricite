<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\ServiceController as AdminServiceController;
use App\Http\Controllers\Admin\ServiceImageController;
use App\Http\Controllers\Api\ContactController;
use App\Http\Controllers\Admin\ContactMessageController;
use App\Models\Service;

/*
|--------------------------------------------------------------------------
| API publique (web.php pour Sanctum côté SPA)
|--------------------------------------------------------------------------
*/
Route::prefix('api')->group(function () {
    // Auth
    Route::post('/auth/login',  [AuthController::class, 'login'])->name('auth.login');
    Route::post('/auth/logout', [AuthController::class, 'logout'])->name('auth.logout');

    // Ping
    Route::get('/ping', fn () => response()->json(['pong' => true]))->name('api.ping');

    // Contact (PUBLIC)
    Route::post('/contact', [ContactController::class, 'store'])
        ->middleware('throttle:5,1')
        ->name('api.contact.store');

    /*
    |--------------------------------------------------------------------------
    | Liste publique des services (actifs)
    |--------------------------------------------------------------------------
    | Règle UX : le texte des cartes (hover) vient de "Description (carte Accueil)".
    | Selon le schéma, ce champ peut s'appeler 'excerpt' ou 'description'.
    | On prend d'abord 'excerpt' s'il existe, sinon 'description'. Pas de fallback sur content.
    */
    Route::get('/services', function () {
        $cols = Schema::getColumnListing('services');
        $q = Service::query();

        if (in_array('is_active', $cols, true)) $q->where('is_active', true);
        if (in_array('position',  $cols, true)) $q->orderBy('position');
        if (in_array('name',      $cols, true)) $q->orderBy('name');

        $services = $q->get();

        $payload = $services->map(function (Service $s) use ($cols) {
            $name = $s->name ?? 'Service';
            $slug = $s->slug ?? Str::slug($name);

            $imagePathUrl = (in_array('image_path', $cols, true) && $s->image_path)
                ? Storage::url($s->image_path)
                : null;

            // ✅ Description courte de la carte : excerpt (si présent) sinon description. Sinon vide.
            $card = '';
            if (in_array('excerpt', $cols, true)) {
                $card = trim((string) ($s->excerpt ?? ''));
            } elseif (in_array('description', $cols, true)) {
                $card = trim((string) ($s->description ?? ''));
            }

            return [
                'id'             => $s->id,
                'name'           => $name,
                'slug'           => $slug,
                'excerpt'        => $card,           // texte hover (court)
                'description'    => $card,           // alias pour compat front
                'image_url'      => $imagePathUrl,
                'image_path_url' => $imagePathUrl,
                'base_price'     => in_array('base_price', $cols, true) ? ($s->base_price ?? 0) : 0,
            ];
        });

        return response()->json($payload);
    })->name('api.services.public');

    /*
    |--------------------------------------------------------------------------
    | Détail public d’un service (par slug)
    |--------------------------------------------------------------------------
    | Nouveau : on expose un champ 'lead' pour le SOUS-TITRE du H1
    | (distinct du texte de carte). On tente plusieurs colonnes possibles :
    | lead, subtitle, intro, summary, hero_subtitle (dans cet ordre). Sinon vide.
    | 'description' dans le détail == card text (cohérence), pas utilisé pour le H1.
    */
    Route::get('/services/{slug}', function (Request $request, string $slug) {
        $cols = Schema::getColumnListing('services');
        $q = Service::query();

        if (in_array('is_active', $cols, true) && !$request->boolean('include_inactive')) {
            $q->where('is_active', true);
        }

        // direct par slug, sinon fallback sur name slugifié
        $service = in_array('slug', $cols, true) ? $q->where('slug', $slug)->first() : null;
        if (!$service) {
            $target = Str::slug($slug);
            $service = $q->get()->first(function ($s) use ($target) {
                $cands = array_filter([$s->name ?? null, $s->slug ?? null]);
                foreach ($cands as $c) {
                    if (Str::slug($c) === $target) return true;
                }
                return false;
            });
        }
        if (!$service) {
            return response()->json(['message' => 'Service not found'], 404);
        }

        $imagePathUrl = (in_array('image_path', $cols, true) && $service->image_path)
            ? Storage::url($service->image_path)
            : null;

        // Texte court de carte (même logique que la liste)
        $card = '';
        if (in_array('excerpt', $cols, true)) {
            $card = trim((string) ($service->excerpt ?? ''));
        } elseif (in_array('description', $cols, true)) {
            $card = trim((string) ($service->description ?? ''));
        }

        // Nouveau : lead (sous-titre du H1), totalement indépendant du card text
        $leadCandidates = ['lead', 'subtitle', 'intro', 'summary', 'hero_subtitle'];
        $lead = '';
        foreach ($leadCandidates as $col) {
            if (in_array($col, $cols, true) && isset($service->{$col})) {
                $lead = trim((string) $service->{$col});
                if ($lead !== '') break;
            }
        }

        return response()->json([
            'id'               => $service->id,
            'name'             => $service->name ?? 'Service',
            'slug'             => $service->slug ?? Str::slug($service->name ?? ''),
            // Texte carte (court) — pas pour le H1
            'excerpt'          => $card,
            'description'      => $card,
            // Sous-titre du H1 (nouveau champ exposé)
            'lead'             => $lead,
            // Contenus longs pour la page détail
            'content'          => in_array('content', $cols, true) ? ($service->content ?? '') : '',
            'content_heading'  => in_array('content_heading', $cols, true) ? ($service->content_heading ?? null) : null,
            'content_md'       => in_array('content_md', $cols, true) ? ($service->content_md ?? null) : null,
            'bottom_note'      => in_array('bottom_note', $cols, true) ? ($service->bottom_note ?? null) : null,
            'base_price'       => in_array('base_price', $cols, true) ? ($service->base_price ?? 0) : 0,
            'image_url'        => $imagePathUrl,
            'image_path_url'   => $imagePathUrl,
            'is_active'        => in_array('is_active', $cols, true) ? (bool) $service->is_active : true,
            'position'         => in_array('position', $cols, true) ? $service->position : null,
        ]);
    })->name('api.services.show');
});

/*
|--------------------------------------------------------------------------
| API Admin (protégée Sanctum)
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')
    ->prefix('api/admin')
    ->as('admin.')
    ->group(function () {
        // CRUD Services
        Route::get   ('/services',           [AdminServiceController::class, 'index'])->name('services.index');
        Route::get   ('/services/{service}', [AdminServiceController::class, 'show'])->name('services.show');
        Route::post  ('/services',           [AdminServiceController::class, 'store'])->name('services.store');
        Route::put   ('/services/{service}', [AdminServiceController::class, 'update'])->name('services.update');
        Route::delete('/services/{service}', [AdminServiceController::class, 'destroy'])->name('services.destroy');

        // Upload / suppression d’image
        Route::post  ('/services/{service}/image',  [ServiceImageController::class, 'store'])->name('services.image.store');
        Route::delete('/services/{service}/image',  [ServiceImageController::class, 'destroy'])->name('services.image.destroy');

        // Messages de contact
        Route::get   ('/contact-messages',                       [ContactMessageController::class, 'index'])->name('contact.index');
        Route::get   ('/contact-messages/{contactMessage}',      [ContactMessageController::class, 'show'])->name('contact.show');
        Route::delete('/contact-messages/{contactMessage}',      [ContactMessageController::class, 'destroy'])->name('contact.destroy');
        Route::post  ('/contact-messages/{contactMessage}/reply',[ContactMessageController::class, 'reply'])->name('contact.reply');

        // Profil Admin connecté
        Route::get('/me', fn (Request $request) => response()->json($request->user()))->name('me');
    });

/*
|--------------------------------------------------------------------------
| SPA React
|--------------------------------------------------------------------------
*/
Route::view('/', 'app');
Route::get('/{any}', fn () => view('app'))
    ->where('any', '^(?!api|sanctum|storage).*$');
