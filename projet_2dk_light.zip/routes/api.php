<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes (stateless)
|--------------------------------------------------------------------------
| Dans ce projet, l’API SPA est servie via routes/web.php (préfixe /api).
| Je garde ce fichier pour un usage externe éventuel plus tard.
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
