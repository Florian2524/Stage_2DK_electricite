# Stage_2DK_electricite
