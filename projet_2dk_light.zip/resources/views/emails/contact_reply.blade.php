<p>Bonjour {{ $name }},</p>
<p style="white-space: pre-wrap">{{ $bodyText }}</p>
<p style="margin-top:16px; font-size:12px; opacity:.7">— Réponse 2DK Électricité —</p>