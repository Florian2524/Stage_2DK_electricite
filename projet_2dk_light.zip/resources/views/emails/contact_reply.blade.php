<!doctype html>
<html lang="fr">
  <body>
    <p>Bonjour {{ $toName }},</p>
    <p style="white-space: pre-wrap;">{{ $bodyText }}</p>
    <p>Cordialement,</p>
    <p>2DK Électricité</p>
  </body>
</html>
