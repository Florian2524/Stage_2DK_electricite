import React from "react";

export default function Separator() {
  return (
    <div className="h-[2px] w-full bg-[#F6C90E]" />
  );
}
